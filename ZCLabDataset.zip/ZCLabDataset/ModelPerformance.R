###############################################
# (1) Performance Assessment of Radiomics Models for Differentiating RCC Subtypes
# (2) Version: 1.0.0
# (3) Date: 2018-07-26
# (4) Description: Calculating the performance measures for all radiomics models
# (5) Requirement: R version 3.5.1, RStudio Version 1.1.453, Win10
# (6) Input: 
# (6.1) five csv files (RCCtrain.csv,RCCtest.csv,RCCtest_Papillary.csv,RCCtest_Chromophobe.csv,heatmap.csv)
# containing Radiomics features for patients in training, valildation and radiogenomics cohorts; 
# (6.2) one RData file (Train_Model.RData) containing trained RandomForest (RF) models.
# (7) Output: 
# (7.1) five csv files (Performance_ccRCCfromNonccRCC.csv,Performance_ccRCCfrompRCC.csv,
# Performance_ccRCCfromChRCC.csv,NamesOfSelectedFeatures.csv,VHL_Pvalue.csv) containing model performance, the names 
# of selected features, and the p values of each selected features; 
# (7.2) three png files (ROC_ccRCCfromNonccRCC.png,ROC_ccRCCfrompRCCAndchRCC,RadiogenomicsMap.png) containg ROC curves and radiogenomics map; 
# (7.3) one RData file (Result.RData) containing all the result data.
###############################################



# set the work directory 
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
wants <- c("caret", "glmnet","randomForest","gbm","survival","lattice","ggplot2","Matrix",
           "pROC","ROCR","Boruta","foreach","mRMRe","ltm")
has <- wants %in% rownames(installed.packages())
if(any(!has)) install.packages(wants[!has])
rm(list = ls())
library(caret)
library(glmnet)
library(randomForest)
library(gbm)
library(pROC)
library(ROCR)
library(Boruta)
library(mRMRe)
library(ltm)
library(pheatmap)
library(grid)
library(fdrtool)

# load the trained random forest model, containing three ones: the RF+Boruta, RF+mRMRe, and RF+Combined
load("./input/Train_Model.RData")
methods <- c( "Boruta", "mRMRe", "Combined")
# load radiomics features of patients in validation cohort
Data_RCCtest <- read.csv("./input/RCCtest.csv")
# load radiomics features of patients in training cohort
Data_RCCtrain <- read.csv("./input/RCCtrain.csv")
# load radiomics features of pRCC patients in validation cohort
Data_RCCTest_Papillary <- read.csv("./input/RCCTest_Papillary.csv")
# load radiomics features of chRCC patients in validation cohort
Data_RCCTest_Chromophobe <- read.csv("./input/RCCtest_Chromophobe.csv")

names(Data_RCCtest) <- gsub("_","",names(Data_RCCtest))
names(Data_RCCtrain) <- gsub("_","",names(Data_RCCtrain))
names(Data_RCCTest_Papillary) <- gsub("_","",names(Data_RCCTest_Papillary))
names(Data_RCCTest_Chromophobe) <- gsub("_","",names(Data_RCCTest_Chromophobe))

M = ncol(Data_RCCtest)
featurenum <- length(NewName_Boruta)
Data_Train <- Data_RCCtrain[,1:(M-3)]
Data_Train <- sample(Data_Train,length(names(Data_Train)),replace = FALSE)
Data_Train$Status <- Data_RCCtrain[,(M):(M)]
Data_Train$Status = factor(Data_Train$Status)
Data_Test <- Data_RCCtest[,1:(M-3)]
Data_Test$Status <- Data_RCCtest[,(M):(M)]
Data_Test_Papillary <- Data_RCCTest_Papillary[,1:(M-3)]
Data_Test_Papillary$Status <- Data_RCCTest_Papillary[,(M):(M)]
Data_Test_Chromophobe <- Data_RCCTest_Chromophobe[,1:(M-3)]
Data_Test_Chromophobe$Status <- Data_RCCTest_Chromophobe[,(M):(M)]

# Calculating performance of Boruta model in differentiating ccRCC from non-ccRCC
if("Boruta" %in% methods) 
  {
  NewData_Train_Boruta <- subset(Data_Train, select = NewName_Boruta)
  NewData_Train_Status_Boruta <- Data_Train$Status
  NewData_Test_Boruta <- subset(Data_Test, select = NewName_Boruta)
  NewData_Test_Status_Boruta <- Data_Test$Status
  
  y1_Boruta= RF_Boruta$votes[,2]
  x1_Boruta = as.numeric(NewData_Train_Status_Boruta) - 1
  roc_train_Boruta <- roc(x1_Boruta, y1_Boruta)
  pred_train_Boruta = prediction(y1_Boruta, x1_Boruta)
  roc.perf_train_Boruta = performance(pred_train_Boruta, 'tpr','fpr')
  cutoff.train_Boruta = coords(roc_train_Boruta,"best", ret = "threshold")
  auc_train_Boruta <- performance(pred_train_Boruta,"auc")
  f_train_Boruta <- performance(pred_train_Boruta,"f")
  Predict_Test_Boruta <- predict(RF_Boruta, newdata = NewData_Test_Boruta, type = 'prob')
  roc_test_Boruta <- roc(NewData_Test_Status_Boruta, Predict_Test_Boruta[,2])
  
  pred_test_Boruta = prediction(Predict_Test_Boruta[,2], NewData_Test_Status_Boruta)
  roc.perf_test_Boruta = performance(pred_test_Boruta,'tpr', 'fpr')
  ind_train_Boruta = max(which(f_train_Boruta@x.values[[1]] >= 0.5))
  
  if (ind_train_Boruta == 1)
  {  ind_train_Boruta = 2 }
  auc.train_Boruta = auc_train_Boruta@y.values[[1]]
  f.train_Boruta = slot(f_train_Boruta, "y.values")[[1]][ind_train_Boruta]
  auc_train_Boruta <- performance(pred_train_Boruta,"auc")
  acc_train_Boruta <- performance(pred_train_Boruta,"acc")
  prec_train_Boruta <- performance(pred_train_Boruta,"prec")
  recal_train_Boruta <- performance(pred_train_Boruta,"rec")
  f_train_Boruta <- performance(pred_train_Boruta,"f")
  npv_train_Boruta <- performance(pred_train_Boruta,"npv")
  spec_train_Boruta <- performance(pred_train_Boruta,"spec")
  auc_test_Boruta <- performance(pred_test_Boruta,"auc")
  acc_test_Boruta <- performance(pred_test_Boruta,"acc")
  prec_test_Boruta <- performance(pred_test_Boruta,"prec")
  recal_test_Boruta <- performance(pred_test_Boruta,"rec")
  f_test_Boruta <- performance(pred_test_Boruta,"f")
  npv_test_Boruta <- performance(pred_test_Boruta,"npv")
  spec_test_Boruta <- performance(pred_test_Boruta,"spec")
  
  ind_test_Boruta = max(which(f_test_Boruta@x.values[[1]] >= 0.5))
  if (ind_test_Boruta == 1)
  {  ind_test_Boruta = 2 }
  auc.train_Boruta = auc_train_Boruta@y.values[[1]]
  acc.train_Boruta = slot(acc_train_Boruta,"y.values")[[1]][ind_train_Boruta]
  prec.train_Boruta = slot(prec_train_Boruta,"y.values")[[1]][ind_train_Boruta]
  recal.train_Boruta = slot(recal_train_Boruta, "y.values")[[1]][ind_train_Boruta]
  f.train_Boruta = slot(f_train_Boruta, "y.values")[[1]][ind_train_Boruta]
  npv.train_Boruta = slot(npv_train_Boruta,"y.values")[[1]][ind_train_Boruta]
  spec.train_Boruta = slot(spec_train_Boruta,"y.values")[[1]][ind_train_Boruta]
  auc.test_Boruta = auc_test_Boruta@y.values[[1]]
  acc.test_Boruta = slot(acc_test_Boruta,"y.values")[[1]][ind_test_Boruta]
  prec.test_Boruta = slot(prec_test_Boruta,"y.values")[[1]][ind_test_Boruta]
  recal.test_Boruta = slot(recal_test_Boruta, "y.values")[[1]][ind_test_Boruta]
  f.test_Boruta = slot(f_test_Boruta, "y.values")[[1]][ind_test_Boruta]
  npv.test_Boruta = slot(npv_test_Boruta,"y.values")[[1]][ind_test_Boruta]
  spec.test_Boruta = slot(spec_test_Boruta,"y.values")[[1]][ind_test_Boruta]
  
  print(c(auc.test_Boruta = auc.test_Boruta, acc.test_Boruta = acc.test_Boruta))
}

# Calculating performance of mRMRe model in differentiating ccRCC from non-ccRCC
if("mRMRe" %in% methods) 
  {
  NewData_Train_mRMRe <- subset(Data_Train, select = NewName_mRMRe)
  NewData_Train_Status_mRMRe <- Data_Train$Status
  NewData_Test_mRMRe <- subset(Data_Test, select = NewName_mRMRe)
  NewData_Test_Status_mRMRe <- Data_Test$Status
  y1_mRMRe = RF_mRMRe$votes[,2]
  x1_mRMRe = as.numeric(NewData_Train_Status_mRMRe)-1
  roc_train_mRMRe <- roc(x1_mRMRe, y1_mRMRe)
  pred_train_mRMRe = prediction(y1_mRMRe, x1_mRMRe)
  roc.perf_train_mRMRe = performance(pred_train_mRMRe, 'tpr','fpr')
  cutoff.train_mRMRe = coords(roc_train_mRMRe,"best", ret = "threshold")
  Predict_Test_mRMRe <- predict(RF_mRMRe, newdata = NewData_Test_mRMRe, type = 'prob')
  roc_test_mRMRe <- roc(NewData_Test_Status_mRMRe, Predict_Test_mRMRe[,2])
  
  pred_test_mRMRe = prediction(Predict_Test_mRMRe[,2], NewData_Test_Status_mRMRe)
  roc.perf_test_mRMRe = performance(pred_test_mRMRe,'tpr', 'fpr')
  auc_train_mRMRe <- performance(pred_train_mRMRe,"auc")
  f_train_mRMRe <- performance(pred_train_mRMRe,"f")
  ind_train_mRMRe = max(which(f_train_mRMRe@x.values[[1]] >= 0.5))
  
  if (ind_train_mRMRe == 1)
  {  ind_train_mRMRe = 2 }
  auc.train_mRMRe = auc_train_mRMRe@y.values[[1]]
  f.train_mRMRe = slot(f_train_mRMRe, "y.values")[[1]][ind_train_mRMRe]
  auc_train_mRMRe <- performance(pred_train_mRMRe,"auc")
  acc_train_mRMRe <- performance(pred_train_mRMRe,"acc")
  prec_train_mRMRe <- performance(pred_train_mRMRe,"prec")
  recal_train_mRMRe <- performance(pred_train_mRMRe,"rec")
  f_train_mRMRe <- performance(pred_train_mRMRe,"f")
  npv_train_mRMRe <- performance(pred_train_mRMRe,"npv")
  spec_train_mRMRe <- performance(pred_train_mRMRe,"spec")
  auc_train_mRMRe <- performance(pred_train_mRMRe,"auc")
  f_train_mRMRe <- performance(pred_train_mRMRe,"f")
  auc_test_mRMRe <- performance(pred_test_mRMRe,"auc")
  acc_test_mRMRe <- performance(pred_test_mRMRe,"acc")
  prec_test_mRMRe <- performance(pred_test_mRMRe,"prec")
  recal_test_mRMRe <- performance(pred_test_mRMRe,"rec")
  f_test_mRMRe <- performance(pred_test_mRMRe,"f")
  npv_test_mRMRe <- performance(pred_test_mRMRe,"npv")
  spec_test_mRMRe <- performance(pred_test_mRMRe,"spec")
  
  ind_test_mRMRe = max(which(f_test_mRMRe@x.values[[1]] >= 0.5))
  if (ind_test_mRMRe == 1)
  {  ind_test_mRMRe = 2 }
  auc.test_mRMRe = auc_test_mRMRe@y.values[[1]]
  acc.test_mRMRe = slot(acc_test_mRMRe,"y.values")[[1]][ind_test_mRMRe]
  prec.test_mRMRe = slot(prec_test_mRMRe,"y.values")[[1]][ind_test_mRMRe]
  recal.test_mRMRe = slot(recal_test_mRMRe, "y.values")[[1]][ind_test_mRMRe]
  f.test_mRMRe = slot(f_test_mRMRe, "y.values")[[1]][ind_test_mRMRe]
  npv.test_mRMRe = slot(npv_test_mRMRe,"y.values")[[1]][ind_test_mRMRe]
  spec.test_mRMRe = slot(spec_test_mRMRe,"y.values")[[1]][ind_test_mRMRe]
  auc.train_mRMRe = auc_train_mRMRe@y.values[[1]]
  acc.train_mRMRe = slot(acc_train_mRMRe,"y.values")[[1]][ind_train_mRMRe]
  prec.train_mRMRe = slot(prec_train_mRMRe,"y.values")[[1]][ind_train_mRMRe]
  recal.train_mRMRe = slot(recal_train_mRMRe, "y.values")[[1]][ind_train_mRMRe]
  f.train_mRMRe = slot(f_train_mRMRe, "y.values")[[1]][ind_train_mRMRe]
  npv.train_mRMRe = slot(npv_train_mRMRe,"y.values")[[1]][ind_train_mRMRe]
  spec.train_mRMRe = slot(spec_train_mRMRe,"y.values")[[1]][ind_train_mRMRe]
  
  print(c(auc.test_mRMRe = auc.test_mRMRe, acc.test_mRMRe = acc.test_mRMRe))
}

# Calculating performance of combined model in differentiating ccRCC from non-ccRCC
if("Combined" %in% methods) 
  {
  NewData_Train_Combined = cbind(NewData_Train_Boruta,Data_RCCtrain[,(M-2):(M-1)])
  NewData_Test_Combined <- subset(Data_Test, select = NewName_Boruta)
  NewData_Test_Status_Combined <- Data_Test$Status
  NewData_Test_Combined = cbind(NewData_Test_Combined,Data_RCCtest[(M-2):(M-1)])
  
  y1_Combined = RF_Combined$votes[,2]
  x1_Combined = as.numeric(NewData_Train_Status_Boruta) - 1
  roc_train_Combined <- roc(x1_Combined, y1_Combined)
  pred_train_Combined = prediction(y1_Combined, x1_Combined)
  roc.perf_train_Combined = performance(pred_train_Combined, 'tpr','fpr')
  cutoff.train_Combined = coords(roc_train_Combined,"best", ret = "threshold")
  Predict_Test_Combined <- predict(RF_Combined, newdata = NewData_Test_Combined, type = 'prob')
  roc_test_Combined <- roc(NewData_Test_Status_Combined, Predict_Test_Combined[,2])
  
  pred_test_Combined = prediction(Predict_Test_Combined[,2], NewData_Test_Status_Combined)
  roc.perf_test_Combined = performance(pred_test_Combined,'tpr', 'fpr')
  auc_train_Combined <- performance(pred_train_Combined,"auc")
  f_train_Combined <- performance(pred_train_Combined,"f")
  ind_train_Combined = max(which(f_train_Combined@x.values[[1]] >= 0.5))
  if (ind_train_Combined == 1)
  {  ind_train_Combined = 2 }
  auc.train_Combined = auc_train_Combined@y.values[[1]]
  f.train_Combined = slot(f_train_Combined, "y.values")[[1]][ind_train_Combined]
  
  auc_train_Combined <- performance(pred_train_Combined,"auc")
  acc_train_Combined <- performance(pred_train_Combined,"acc")
  prec_train_Combined <- performance(pred_train_Combined,"prec")
  recal_train_Combined <- performance(pred_train_Combined,"rec")
  f_train_Combined <- performance(pred_train_Combined,"f")
  npv_train_Combined <- performance(pred_train_Combined,"npv")
  spec_train_Combined <- performance(pred_train_Combined,"spec")
  auc_test_Combined <- performance(pred_test_Combined,"auc")
  acc_test_Combined <- performance(pred_test_Combined,"acc")
  prec_test_Combined <- performance(pred_test_Combined,"prec")
  recal_test_Combined <- performance(pred_test_Combined,"rec")
  f_test_Combined <- performance(pred_test_Combined,"f")
  npv_test_Combined <- performance(pred_test_Combined,"npv")
  spec_test_Combined <- performance(pred_test_Combined,"spec")
  
  ind_test_Combined = max(which(f_test_Combined@x.values[[1]] >= 0.5))
  if (ind_test_Combined == 1)
  {  ind_test_Combined = 2 }
  auc.test_Combined = auc_test_Combined@y.values[[1]]
  acc.test_Combined = slot(acc_test_Combined,"y.values")[[1]][ind_test_Combined]
  prec.test_Combined = slot(prec_test_Combined,"y.values")[[1]][ind_test_Combined]
  recal.test_Combined = slot(recal_test_Combined, "y.values")[[1]][ind_test_Combined]
  f.test_Combined = slot(f_test_Combined, "y.values")[[1]][ind_test_Combined]
  npv.test_Combined = slot(npv_test_Combined,"y.values")[[1]][ind_test_Combined]
  spec.test_Combined = slot(spec_test_Combined,"y.values")[[1]][ind_test_Combined]
  auc.train_Combined = auc_train_Combined@y.values[[1]]
  acc.train_Combined = slot(acc_train_Combined,"y.values")[[1]][ind_train_Combined]
  prec.train_Combined = slot(prec_train_Combined,"y.values")[[1]][ind_train_Combined]
  recal.train_Combined = slot(recal_train_Combined, "y.values")[[1]][ind_train_Combined]
  f.train_Combined = slot(f_train_Combined, "y.values")[[1]][ind_train_Combined]
  npv.train_Combined = slot(npv_train_Combined,"y.values")[[1]][ind_train_Combined]
  spec.train_Combined = slot(spec_train_Combined,"y.values")[[1]][ind_train_Combined]
  
  print(c(auc.test_Combined = auc.test_Combined, acc.test_Combined = acc.test_Combined))
}

# Calculating performance of Boruta model in differentiating ccRCC from pRCC
if("Boruta" %in% methods) {
  NewData_Test_Papillary_Boruta <- subset(Data_Test_Papillary, select = NewName_Boruta)
  NewData_Test_Papillary_Status_Boruta <- Data_Test_Papillary$Status
  
  Predict_Test_Papillary_Boruta <- predict(RF_Boruta, newdata = NewData_Test_Papillary_Boruta, type = 'prob')
  roc_Test_Papillary_Boruta <- roc(NewData_Test_Papillary_Status_Boruta, Predict_Test_Papillary_Boruta[,2])
  
  pred_Test_Papillary_Boruta = prediction(Predict_Test_Papillary_Boruta[,2], NewData_Test_Papillary_Status_Boruta)
  roc.perf_Test_Papillary_Boruta = performance(pred_Test_Papillary_Boruta,'tpr', 'fpr')
  
  auc_Test_Papillary_Boruta <- performance(pred_Test_Papillary_Boruta,"auc")
  acc_Test_Papillary_Boruta <- performance(pred_Test_Papillary_Boruta,"acc")
  prec_Test_Papillary_Boruta <- performance(pred_Test_Papillary_Boruta,"prec")
  recal_Test_Papillary_Boruta <- performance(pred_Test_Papillary_Boruta,"rec")
  f_Test_Papillary_Boruta <- performance(pred_Test_Papillary_Boruta,"f")
  npv_Test_Papillary_Boruta <- performance(pred_Test_Papillary_Boruta,"npv")
  spec_Test_Papillary_Boruta <- performance(pred_Test_Papillary_Boruta,"spec")
  
  ind_Test_Papillary_Boruta = max(which(f_Test_Papillary_Boruta@x.values[[1]] >= 0.5))
  if (ind_Test_Papillary_Boruta == 1)
  {  ind_Test_Papillary_Boruta = 2 }
  
  auc.Test_Papillary_Boruta = auc_Test_Papillary_Boruta@y.values[[1]]
  acc.Test_Papillary_Boruta = slot(acc_Test_Papillary_Boruta,"y.values")[[1]][ind_Test_Papillary_Boruta]
  prec.Test_Papillary_Boruta = slot(prec_Test_Papillary_Boruta,"y.values")[[1]][ind_Test_Papillary_Boruta]
  recal.Test_Papillary_Boruta = slot(recal_Test_Papillary_Boruta, "y.values")[[1]][ind_Test_Papillary_Boruta]
  f.Test_Papillary_Boruta = slot(f_Test_Papillary_Boruta, "y.values")[[1]][ind_Test_Papillary_Boruta]
  npv.Test_Papillary_Boruta = slot(npv_Test_Papillary_Boruta,"y.values")[[1]][ind_Test_Papillary_Boruta]
  spec.Test_Papillary_Boruta = slot(spec_Test_Papillary_Boruta,"y.values")[[1]][ind_Test_Papillary_Boruta]
  
  print(c(auc.Test_Papillary_Boruta = auc.Test_Papillary_Boruta, acc.Test_Papillary_Boruta = acc.Test_Papillary_Boruta))
}

# Calculating performance of mRMRe model in differentiating ccRCC from pRCC
if("mRMRe" %in% methods) {
  NewData_Test_Papillary_mRMRe <- subset(Data_Test_Papillary, select = NewName_mRMRe)
  NewData_Test_Papillary_Status_mRMRe <- Data_Test_Papillary$Status
  
  Predict_Test_Papillary_mRMRe <- predict(RF_mRMRe, newdata = NewData_Test_Papillary_mRMRe, type = 'prob')
  roc_Test_Papillary_mRMRe <- roc(NewData_Test_Papillary_Status_mRMRe, Predict_Test_Papillary_mRMRe[,2])
  
  pred_Test_Papillary_mRMRe = prediction(Predict_Test_Papillary_mRMRe[,2], NewData_Test_Papillary_Status_mRMRe)
  roc.perf_Test_Papillary_mRMRe = performance(pred_Test_Papillary_mRMRe,'tpr', 'fpr')
  
  auc_Test_Papillary_mRMRe <- performance(pred_Test_Papillary_mRMRe,"auc")
  acc_Test_Papillary_mRMRe <- performance(pred_Test_Papillary_mRMRe,"acc")
  prec_Test_Papillary_mRMRe <- performance(pred_Test_Papillary_mRMRe,"prec")
  recal_Test_Papillary_mRMRe <- performance(pred_Test_Papillary_mRMRe,"rec")
  f_Test_Papillary_mRMRe <- performance(pred_Test_Papillary_mRMRe,"f")
  npv_Test_Papillary_mRMRe <- performance(pred_Test_Papillary_mRMRe,"npv")
  spec_Test_Papillary_mRMRe <- performance(pred_Test_Papillary_mRMRe,"spec")
  
  ind_Test_Papillary_mRMRe = max(which(f_Test_Papillary_mRMRe@x.values[[1]] >= 0.5))
  if (ind_Test_Papillary_mRMRe == 1)
  {  ind_Test_Papillary_mRMRe = 2 }
  
  auc.Test_Papillary_mRMRe = auc_Test_Papillary_mRMRe@y.values[[1]]
  acc.Test_Papillary_mRMRe = slot(acc_Test_Papillary_mRMRe,"y.values")[[1]][ind_Test_Papillary_mRMRe]
  prec.Test_Papillary_mRMRe = slot(prec_Test_Papillary_mRMRe,"y.values")[[1]][ind_Test_Papillary_mRMRe]
  recal.Test_Papillary_mRMRe = slot(recal_Test_Papillary_mRMRe, "y.values")[[1]][ind_Test_Papillary_mRMRe]
  f.Test_Papillary_mRMRe = slot(f_Test_Papillary_mRMRe, "y.values")[[1]][ind_Test_Papillary_mRMRe]
  npv.Test_Papillary_mRMRe = slot(npv_Test_Papillary_mRMRe,"y.values")[[1]][ind_Test_Papillary_mRMRe]
  spec.Test_Papillary_mRMRe = slot(spec_Test_Papillary_mRMRe,"y.values")[[1]][ind_Test_Papillary_mRMRe]
  
  print(c(auc.Test_Papillary_mRMRe = auc.Test_Papillary_mRMRe, acc.Test_Papillary_mRMRe = acc.Test_Papillary_mRMRe))
}

# Calculating performance of combined model in differentiating ccRCC from pRCC
if("Combined" %in% methods) {
  NewData_Test_Papillary_Combined <- subset(Data_Test_Papillary, select = NewName_Boruta)
  NewData_Test_Papillary_Status_Combined <- Data_Test_Papillary$Status
  NewData_Test_Papillary_Combined = cbind(NewData_Test_Papillary_Combined,Data_RCCTest_Papillary[(M-2):(M-1)])
  
  Predict_Test_Papillary_Combined <- predict(RF_Combined, newdata = NewData_Test_Papillary_Combined, type = 'prob')
  roc_Test_Papillary_Combined <- roc(NewData_Test_Papillary_Status_Combined, Predict_Test_Papillary_Combined[,2])
  
  pred_Test_Papillary_Combined = prediction(Predict_Test_Papillary_Combined[,2], NewData_Test_Papillary_Status_Combined)
  roc.perf_Test_Papillary_Combined = performance(pred_Test_Papillary_Combined,'tpr', 'fpr')
  
  auc_Test_Papillary_Combined <- performance(pred_Test_Papillary_Combined,"auc")
  acc_Test_Papillary_Combined <- performance(pred_Test_Papillary_Combined,"acc")
  prec_Test_Papillary_Combined <- performance(pred_Test_Papillary_Combined,"prec")
  recal_Test_Papillary_Combined <- performance(pred_Test_Papillary_Combined,"rec")
  f_Test_Papillary_Combined <- performance(pred_Test_Papillary_Combined,"f")
  npv_Test_Papillary_Combined <- performance(pred_Test_Papillary_Combined,"npv")
  spec_Test_Papillary_Combined <- performance(pred_Test_Papillary_Combined,"spec")
  
  ind_Test_Papillary_Combined = max(which(f_Test_Papillary_Combined@x.values[[1]] >= 0.5))
  if (ind_Test_Papillary_Combined == 1)
  {  ind_Test_Papillary_Combined = 2 }
  
  auc.Test_Papillary_Combined = auc_Test_Papillary_Combined@y.values[[1]]
  acc.Test_Papillary_Combined = slot(acc_Test_Papillary_Combined,"y.values")[[1]][ind_Test_Papillary_Combined]
  prec.Test_Papillary_Combined = slot(prec_Test_Papillary_Combined,"y.values")[[1]][ind_Test_Papillary_Combined]
  recal.Test_Papillary_Combined = slot(recal_Test_Papillary_Combined, "y.values")[[1]][ind_Test_Papillary_Combined]
  f.Test_Papillary_Combined = slot(f_Test_Papillary_Combined, "y.values")[[1]][ind_Test_Papillary_Combined]
  npv.Test_Papillary_Combined = slot(npv_Test_Papillary_Combined,"y.values")[[1]][ind_Test_Papillary_Combined]
  spec.Test_Papillary_Combined = slot(spec_Test_Papillary_Combined,"y.values")[[1]][ind_Test_Papillary_Combined]
  
  print(c(auc.Test_Papillary_Combined = auc.Test_Papillary_Combined, acc.Test_Papillary_Combined = acc.Test_Papillary_Combined))
  }

# Calculating performance of Boruta model in differentiating ccRCC from chRCC
if("Boruta" %in% methods) {
  NewData_Test_Chromophobe_Boruta <- subset(Data_Test_Chromophobe, select = NewName_Boruta)
  NewData_Test_Chromophobe_Status_Boruta <- Data_Test_Chromophobe$Status
  
  Predict_Test_Chromophobe_Boruta <- predict(RF_Boruta, newdata = NewData_Test_Chromophobe_Boruta, type = 'prob')
  roc_Test_Chromophobe_Boruta <- roc(NewData_Test_Chromophobe_Status_Boruta, Predict_Test_Chromophobe_Boruta[,2])
  
  pred_Test_Chromophobe_Boruta = prediction(Predict_Test_Chromophobe_Boruta[,2], NewData_Test_Chromophobe_Status_Boruta)
  roc.perf_Test_Chromophobe_Boruta = performance(pred_Test_Chromophobe_Boruta,'tpr', 'fpr')
  
  auc_Test_Chromophobe_Boruta <- performance(pred_Test_Chromophobe_Boruta,"auc")
  acc_Test_Chromophobe_Boruta <- performance(pred_Test_Chromophobe_Boruta,"acc")
  prec_Test_Chromophobe_Boruta <- performance(pred_Test_Chromophobe_Boruta,"prec")
  recal_Test_Chromophobe_Boruta <- performance(pred_Test_Chromophobe_Boruta,"rec")
  f_Test_Chromophobe_Boruta <- performance(pred_Test_Chromophobe_Boruta,"f")
  npv_Test_Chromophobe_Boruta <- performance(pred_Test_Chromophobe_Boruta,"npv")
  spec_Test_Chromophobe_Boruta <- performance(pred_Test_Chromophobe_Boruta,"spec")
  
  ind_Test_Chromophobe_Boruta = max(which(f_Test_Chromophobe_Boruta@x.values[[1]] >= 0.5))
  if (ind_Test_Chromophobe_Boruta == 1)
  {  ind_Test_Chromophobe_Boruta = 2 }
  
  auc.Test_Chromophobe_Boruta = auc_Test_Chromophobe_Boruta@y.values[[1]]
  acc.Test_Chromophobe_Boruta = slot(acc_Test_Chromophobe_Boruta,"y.values")[[1]][ind_Test_Chromophobe_Boruta]
  prec.Test_Chromophobe_Boruta = slot(prec_Test_Chromophobe_Boruta,"y.values")[[1]][ind_Test_Chromophobe_Boruta]
  recal.Test_Chromophobe_Boruta = slot(recal_Test_Chromophobe_Boruta, "y.values")[[1]][ind_Test_Chromophobe_Boruta]
  f.Test_Chromophobe_Boruta = slot(f_Test_Chromophobe_Boruta, "y.values")[[1]][ind_Test_Chromophobe_Boruta]
  npv.Test_Chromophobe_Boruta = slot(npv_Test_Chromophobe_Boruta,"y.values")[[1]][ind_Test_Chromophobe_Boruta]
  spec.Test_Chromophobe_Boruta = slot(spec_Test_Chromophobe_Boruta,"y.values")[[1]][ind_Test_Chromophobe_Boruta]
  
  print(c(auc.Test_Chromophobe_Boruta = auc.Test_Chromophobe_Boruta, acc.Test_Chromophobe_Boruta = acc.Test_Chromophobe_Boruta))
}

# Calculating performance of mRMRe model in differentiating ccRCC from chRCC
if("mRMRe" %in% methods) {
  NewData_Test_Chromophobe_mRMRe <- subset(Data_Test_Chromophobe, select = NewName_mRMRe)
  NewData_Test_Chromophobe_Status_mRMRe <- Data_Test_Chromophobe$Status
  
  Predict_Test_Chromophobe_mRMRe <- predict(RF_mRMRe, newdata = NewData_Test_Chromophobe_mRMRe, type = 'prob')
  roc_Test_Chromophobe_mRMRe <- roc(NewData_Test_Chromophobe_Status_mRMRe, Predict_Test_Chromophobe_mRMRe[,2])
  
  pred_Test_Chromophobe_mRMRe = prediction(Predict_Test_Chromophobe_mRMRe[,2], NewData_Test_Chromophobe_Status_mRMRe)
  roc.perf_Test_Chromophobe_mRMRe = performance(pred_Test_Chromophobe_mRMRe,'tpr', 'fpr')
  
  auc_Test_Chromophobe_mRMRe <- performance(pred_Test_Chromophobe_mRMRe,"auc")
  acc_Test_Chromophobe_mRMRe <- performance(pred_Test_Chromophobe_mRMRe,"acc")
  prec_Test_Chromophobe_mRMRe <- performance(pred_Test_Chromophobe_mRMRe,"prec")
  recal_Test_Chromophobe_mRMRe <- performance(pred_Test_Chromophobe_mRMRe,"rec")
  f_Test_Chromophobe_mRMRe <- performance(pred_Test_Chromophobe_mRMRe,"f")
  npv_Test_Chromophobe_mRMRe <- performance(pred_Test_Chromophobe_mRMRe,"npv")
  spec_Test_Chromophobe_mRMRe <- performance(pred_Test_Chromophobe_mRMRe,"spec")
  
  ind_Test_Chromophobe_mRMRe = max(which(f_Test_Chromophobe_mRMRe@x.values[[1]] >= 0.5))
  if (ind_Test_Chromophobe_mRMRe == 1)
  {  ind_Test_Chromophobe_mRMRe = 2 }
  
  auc.Test_Chromophobe_mRMRe = auc_Test_Chromophobe_mRMRe@y.values[[1]]
  acc.Test_Chromophobe_mRMRe = slot(acc_Test_Chromophobe_mRMRe,"y.values")[[1]][ind_Test_Chromophobe_mRMRe]
  prec.Test_Chromophobe_mRMRe = slot(prec_Test_Chromophobe_mRMRe,"y.values")[[1]][ind_Test_Chromophobe_mRMRe]
  recal.Test_Chromophobe_mRMRe = slot(recal_Test_Chromophobe_mRMRe, "y.values")[[1]][ind_Test_Chromophobe_mRMRe]
  f.Test_Chromophobe_mRMRe = slot(f_Test_Chromophobe_mRMRe, "y.values")[[1]][ind_Test_Chromophobe_mRMRe]
  npv.Test_Chromophobe_mRMRe = slot(npv_Test_Chromophobe_mRMRe,"y.values")[[1]][ind_Test_Chromophobe_mRMRe]
  spec.Test_Chromophobe_mRMRe = slot(spec_Test_Chromophobe_mRMRe,"y.values")[[1]][ind_Test_Chromophobe_mRMRe]
  
  print(c(auc.Test_Chromophobe_mRMRe = auc.Test_Chromophobe_mRMRe, acc.Test_Chromophobe_mRMRe = acc.Test_Chromophobe_mRMRe))
}

# Calculating performance of combined model in differentiating ccRCC from chRCC
if("Combined" %in% methods) {
  NewData_Test_Chromophobe_Combined <- subset(Data_Test_Chromophobe, select = NewName_Boruta)
  NewData_Test_Chromophobe_Status_Combined <- Data_Test_Chromophobe$Status
  NewData_Test_Chromophobe_Combined = cbind(NewData_Test_Chromophobe_Combined,Data_RCCTest_Chromophobe[(M-2):(M-1)])
  
  Predict_Test_Chromophobe_Combined <- predict(RF_Combined, newdata = NewData_Test_Chromophobe_Combined, type = 'prob')
  roc_Test_Chromophobe_Combined <- roc(NewData_Test_Chromophobe_Status_Combined, Predict_Test_Chromophobe_Combined[,2])
  
  pred_Test_Chromophobe_Combined = prediction(Predict_Test_Chromophobe_Combined[,2], NewData_Test_Chromophobe_Status_Combined)
  roc.perf_Test_Chromophobe_Combined = performance(pred_Test_Chromophobe_Combined,'tpr', 'fpr')
  
  auc_Test_Chromophobe_Combined <- performance(pred_Test_Chromophobe_Combined,"auc")
  acc_Test_Chromophobe_Combined <- performance(pred_Test_Chromophobe_Combined,"acc")
  prec_Test_Chromophobe_Combined <- performance(pred_Test_Chromophobe_Combined,"prec")
  recal_Test_Chromophobe_Combined <- performance(pred_Test_Chromophobe_Combined,"rec")
  f_Test_Chromophobe_Combined <- performance(pred_Test_Chromophobe_Combined,"f")
  npv_Test_Chromophobe_Combined <- performance(pred_Test_Chromophobe_Combined,"npv")
  spec_Test_Chromophobe_Combined <- performance(pred_Test_Chromophobe_Combined,"spec")
  
  ind_Test_Chromophobe_Combined = max(which(f_Test_Chromophobe_Combined@x.values[[1]] >= 0.5))
  if (ind_Test_Chromophobe_Combined == 1)
  {  ind_Test_Chromophobe_Combined = 2 }
  
  auc.Test_Chromophobe_Combined = auc_Test_Chromophobe_Combined@y.values[[1]]
  acc.Test_Chromophobe_Combined = slot(acc_Test_Chromophobe_Combined,"y.values")[[1]][ind_Test_Chromophobe_Combined]
  prec.Test_Chromophobe_Combined = slot(prec_Test_Chromophobe_Combined,"y.values")[[1]][ind_Test_Chromophobe_Combined]
  recal.Test_Chromophobe_Combined = slot(recal_Test_Chromophobe_Combined, "y.values")[[1]][ind_Test_Chromophobe_Combined]
  f.Test_Chromophobe_Combined = slot(f_Test_Chromophobe_Combined, "y.values")[[1]][ind_Test_Chromophobe_Combined]
  npv.Test_Chromophobe_Combined = slot(npv_Test_Chromophobe_Combined,"y.values")[[1]][ind_Test_Chromophobe_Combined]
  spec.Test_Chromophobe_Combined = slot(spec_Test_Chromophobe_Combined,"y.values")[[1]][ind_Test_Chromophobe_Combined]
  print(c(auc.Test_Chromophobe_Combined = auc.Test_Chromophobe_Combined, acc.Test_Chromophobe_Combined = acc.Test_Chromophobe_Combined))
  }

# Output all result data in RData file
print(c)
FileName = paste("./output/Result.RData")
save.image(FileName)

# Record model performance for differentiating ccRCC from non-ccRCC in both training and validation cohorts
list_record = list()
list_featurename = list()
list_name = c(
  'Boruta', 
  'acc.train_Boruta','auc.train_Boruta','sens.train_Boruta','spec.train_Boruta',
  'ppv.train_Boruta', 'npv.train_Boruta','f.train_Boruta',
  'acc.test_Boruta', 'auc.test_Boruta','sens.test_Boruta','spec.test_Boruta',
  'ppv.test_Boruta','npv.test_Boruta','f.test_Boruta',
  'mRMRe',
  'acc.train_mRMRe','auc.train_mRMRe','sens.train_mRMRe','spec.train_mRMRe',
  'ppv.train_mRMRe','npv.train_mRMRe','f.train_mRMRe', 
  'acc.test_mRMRe','auc.test_mRMRe','sens.test_mRMRe','spec.test_mRMRe',
  'ppv.test_mRMRe','npv.test_mRMRe',  'f.test_mRMRe',
  'Combined',
  'acc.train_Combined', 'auc.train_Combined','sens.train_Combined','spec.train_Combined',
  'ppv.train_Combined', 'npv.train_Combined','f.train_Combined',
  'acc.test_Combined','auc.test_Combined','sens.test_Combined','spec.test_Combined',
  'ppv.test_Combined','npv.test_Combined','f.test_Combined' 
)
list_value = c(
  '/',
  acc.train_Boruta,auc.train_Boruta,recal.train_Boruta,spec.train_Boruta,
  prec.train_Boruta, npv.train_Boruta,f.train_Boruta,
  acc.test_Boruta, auc.test_Boruta,recal.test_Boruta,spec.test_Boruta,
  prec.test_Boruta,npv.test_Boruta,f.test_Boruta,
  '/',
  acc.train_mRMRe,auc.train_mRMRe,recal.train_mRMRe,spec.train_mRMRe,
  prec.train_mRMRe,npv.train_mRMRe,f.train_mRMRe, 
  acc.test_mRMRe, auc.test_mRMRe,recal.test_mRMRe,spec.test_mRMRe,
  prec.test_mRMRe, npv.test_mRMRe,  f.test_mRMRe,
  '/',
  acc.train_Combined, auc.train_Combined,recal.train_Combined,spec.train_Combined,
  prec.train_Combined, npv.train_Combined,f.train_Combined,
  acc.test_Combined,auc.test_Combined,recal.test_Combined,spec.test_Combined,
  prec.test_Combined,npv.test_Combined,f.test_Combined 
)
list_featurename = c('mRMRe', NewName_mRMRe, 'Boruta', NewName_Boruta)
list_record = cbind(list_name, list_value)

# Record model performance for differentiating ccRCC from pRCC in validation cohort
list_record_p = list()
list_name_p = c(
  'Boruta',
  'acc.Test_Papillary_Boruta',  'auc.Test_Papillary_Boruta',
  'sens.Test_Papillary_Boruta', 'spec.Test_Papillary_Boruta',
  'ppv.Test_Papillary_Boruta',  'npv.Test_Papillary_Boruta',
  'f.Test_Papillary_Boruta',
  'mRMRe',
  'acc.Test_Papillary_mRMRe',  'auc.Test_Papillary_mRMRe',   
  'sens.Test_Papillary_mRMRe', 'spec.Test_Papillary_mRMRe' ,
  'ppv.Test_Papillary_mRMRe',  'npv.Test_Papillary_mRMRe',  
  'f.Test_Papillary_mRMRe',
  'Combined',
  'acc.Test_Papillary_Combined',  'auc.Test_Papillary_Combined', 
  'sens.Test_Papillary_Combined', 'spec.Test_Papillary_Combined',
  'ppv.Test_Papillary_Combined',  'npv.Test_Papillary_Combined',
  'f.Test_Papillary_Combined'
 )
list_value_p = c(
  '/',
  acc.Test_Papillary_Boruta,   auc.Test_Papillary_Boruta,
  recal.Test_Papillary_Boruta, spec.Test_Papillary_Boruta, 
  prec.Test_Papillary_Boruta,  npv.Test_Papillary_Boruta,
  f.Test_Papillary_Boruta,
  '/',
  acc.Test_Papillary_mRMRe,   auc.Test_Papillary_mRMRe,   
  recal.Test_Papillary_mRMRe, spec.Test_Papillary_mRMRe,
  prec.Test_Papillary_mRMRe,  npv.Test_Papillary_mRMRe,  
  f.Test_Papillary_mRMRe,  
  '/',
  acc.Test_Papillary_Combined,   auc.Test_Papillary_Combined, 
  recal.Test_Papillary_Combined, spec.Test_Papillary_Combined,
  prec.Test_Papillary_Combined,  npv.Test_Papillary_Combined,
  f.Test_Papillary_Combined
)
list_record_p = cbind(list_name_p, list_value_p)

# Record model performance for differentiating ccRCC from chRCC in validation cohort
list_record_c = list()
list_name_c = c(
  'Boruta',
  'acc.Test_Chromophobe_Boruta',  'auc.Test_Chromophobe_Boruta',
  'sens.Test_Chromophobe_Boruta', 'spec.Test_Chromophobe_Boruta',
  'ppv.Test_Chromophobe_Boruta',  'npv.Test_Chromophobe_Boruta',
  'f.Test_Chromophobe_Boruta',
  'mRMRe',
  'acc.Test_Chromophobe_mRMRe',  'auc.Test_Chromophobe_mRMRe',   
  'sens.Test_Chromophobe_mRMRe', 'spec.Test_Chromophobe_mRMRe' ,
  'ppv.Test_Chromophobe_mRMRe',  'npv.Test_Chromophobe_mRMRe',  
  'f.Test_Chromophobe_mRMRe',
  'Combined',
  'acc.Test_Chromophobe_Combined',  'auc.Test_Chromophobe_Combined', 
  'sens.Test_Chromophobe_Combined', 'spec.Test_Chromophobe_Combined',
  'ppv.Test_Chromophobe_Combined',  'npv.Test_Chromophobe_Combined',
  'f.Test_Chromophobe_Combined')
list_value_c = c(
  '/',
  acc.Test_Chromophobe_Boruta,   auc.Test_Chromophobe_Boruta,
  recal.Test_Chromophobe_Boruta, spec.Test_Chromophobe_Boruta, 
  prec.Test_Chromophobe_Boruta,  npv.Test_Chromophobe_Boruta,
  f.Test_Chromophobe_Boruta,
  '/',
  acc.Test_Chromophobe_mRMRe,   auc.Test_Chromophobe_mRMRe,   
  recal.Test_Chromophobe_mRMRe, spec.Test_Chromophobe_mRMRe,
  prec.Test_Chromophobe_mRMRe,  npv.Test_Chromophobe_mRMRe,  
  f.Test_Chromophobe_mRMRe,  
  '/',
  acc.Test_Chromophobe_Combined,   auc.Test_Chromophobe_Combined, 
  recal.Test_Chromophobe_Combined, spec.Test_Chromophobe_Combined,
  prec.Test_Chromophobe_Combined,  npv.Test_Chromophobe_Combined,
  f.Test_Chromophobe_Combined
)
list_record_c = cbind(list_name_c, list_value_c)

# Output performance in csv files
write.csv(list_featurename, file = "./output/NamesOfSelectedFeatures.csv", row.names = TRUE)
write.csv(list_record, file = "./output/Performance_ccRCCfromNonccRCC.csv", row.names = TRUE)
write.csv(list_record_p, file = "./output/Performance_ccRCCfrompRCC.csv", row.names = FALSE)
write.csv(list_record_c, file = "./output/Performance_ccRCCfromchRCC.csv", row.names = FALSE)

# Plot training ROC curves of Boruta, mRMRe and Combined models for differentiating ccRCC from non-ccRCC in png files
png(file = paste('./output/ROC_ccRCCfromNonccRCC.png.',sep=''), width = 1200, height = 800)
par(mfrow=c(2,3),cex=1.1)
plot.roc(roc_train_Boruta, main = "Training ROC Boruta", print.auc = TRUE,auc.polygon = TRUE,
         max.auc.polygon = TRUE, auc.polygon.col = "skyblue")
plot.roc(roc_train_mRMRe, main = "Training ROC mRMRe", print.auc = TRUE, auc.polygon = TRUE,
         max.auc.polygon = TRUE, auc.polygon.col = "skyblue")
plot.roc(roc_train_Combined, main = "Training ROC Combined", print.auc = TRUE, auc.polygon = TRUE,
         max.auc.polygon = TRUE, auc.polygon.col = "skyblue")
plot.roc(roc_test_Boruta, main = "Validation ROC Boruta", print.auc = TRUE,auc.polygon = TRUE,
         max.auc.polygon = TRUE, auc.polygon.col = "skyblue")
plot.roc(roc_test_mRMRe, main = "Validation ROC mRMRe", print.auc = TRUE, auc.polygon = TRUE,
         max.auc.polygon = TRUE, auc.polygon.col = "skyblue")
plot.roc(roc_test_Combined, main = "Validation ROC Combined", print.auc = TRUE, auc.polygon = TRUE,
         max.auc.polygon = TRUE, auc.polygon.col = "skyblue")
dev.off()


# Plot training ROC curves of Boruta, mRMRe and Combined models for differentiating ccRCC from non-ccRCC in png files
png(file = paste('./output/ROC_ccRCCfrompccRCCAndchRCC.png.',sep=''), width = 1200, height = 800)
par(mfrow=c(2,3),cex=1.1)
plot.roc(roc_Test_Papillary_Boruta, main = "ROC Boruta ccRCCfrompRCC", print.auc = TRUE,auc.polygon = TRUE,
         max.auc.polygon = TRUE, auc.polygon.col = "skyblue")
plot.roc(roc_Test_Papillary_mRMRe, main = "ROC mRMRe ccRCCfrompRCC", print.auc = TRUE, auc.polygon = TRUE,
         max.auc.polygon = TRUE, auc.polygon.col = "skyblue")
plot.roc(roc_Test_Papillary_Combined, main = "ROC Combined ccRCCfrompRCC", print.auc = TRUE, auc.polygon = TRUE,
         max.auc.polygon = TRUE, auc.polygon.col = "skyblue")
plot.roc(roc_Test_Chromophobe_Boruta, main = "ROC Boruta ccRCCfromchRCC", print.auc = TRUE,auc.polygon = TRUE,
         max.auc.polygon = TRUE, auc.polygon.col = "skyblue")
plot.roc(roc_Test_Chromophobe_mRMRe, main = "ROC mRMRe ccRCCfromchRCC", print.auc = TRUE, auc.polygon = TRUE,
         max.auc.polygon = TRUE, auc.polygon.col = "skyblue")
plot.roc(roc_Test_Chromophobe_Combined, main = "ROC Combined ccRCCfromchRCC", print.auc = TRUE, auc.polygon = TRUE,
         max.auc.polygon = TRUE, auc.polygon.col = "skyblue")
dev.off()

######################################################
# calculating P and FDR-adjusted P values for each feature 
Data_VHL <- read.csv("./input/RCC_VHL.csv")

names(Data_VHL) <- gsub("_","",names(Data_VHL))

list_Pvalue_VHL_ALL = list()
list_Pvalue_VHL = list()
for (j in 1:(ncol(Data_VHL))) 
{
  list_Pvalue_VHL = rbind(list_Pvalue_VHL, wilcox.test(Data_VHL[,j][which(Data_VHL$VHL == '0')], Data_VHL[,j][which(Data_VHL$VHL == '1')])$p.value)
}
fdr = fdrtool(as.numeric(list_Pvalue_VHL), statistic="pvalue", cutoff.method="fndr", plot = FALSE)
list_Pvalue_VHL_ALL = cbind(colnames(Data_VHL), list_Pvalue_VHL, fdr$qval)
list_Pvalue_VHL_selected <- rbind('mRMRe', subset(list_Pvalue_VHL_ALL, list_Pvalue_VHL_ALL[,1]%in%NewName_mRMRe),
                                  'Boruta', subset(list_Pvalue_VHL_ALL, list_Pvalue_VHL_ALL[,1]%in%NewName_Boruta))
colnames(list_Pvalue_VHL_selected) <- c('Feature','pvalue','pfdr')

write.csv(list_Pvalue_VHL_selected, file = "./output/VHL_Pvalue.csv", row.names = FALSE)

########################################################################
# plot the Radiogenomics heatmap to illurstate the imaging-VHL-subtype association
Data_heatmap <- read.csv("./input/heatmap.csv",header=TRUE)
Data_heatmap1 <- Data_heatmap[,2:120]
rownames(Data_heatmap1) <- Data_heatmap[,1:1]

P_value = as.numeric(list_Pvalue_VHL_selected[,3][11:18])
names(P_value) = list_Pvalue_VHL_selected[,1][11:18]
Importance = RF_Boruta$importance[,4]
list_Boruta = merge(data.frame(P_value), data.frame(Importance), by.x = "row.names", by.y = "row.names")
P_value = as.numeric(list_Pvalue_VHL_selected[,3][2:9])
names(P_value) = list_Pvalue_VHL_selected[,1][2:9]
Importance = RF_mRMRe$importance[,4]
list_mRMRe = merge(data.frame(P_value), data.frame(Importance), by.x = "row.names", by.y = "row.names")
list_merge = rbind(list_Boruta[order(list_Boruta[2]),], list_mRMRe[order(list_mRMRe[2]),])
annotation_col = data.frame(
  Subtype = factor(rep(c("non-ccRCC", "ccRCC","non-ccRCC", "ccRCC"), c(19, 24,11,65))),
  VHL = factor(rep(c("unmutated", "mutated"), c(43,76))))
annotation_row = data.frame( P_value = list_merge[2],
                             Importance = list_merge[3])
ann_colors = list(Subtype = c("non-ccRCC" = "DarkGoldenrod", "ccRCC" = "forestgreen"),
                  VHL = c( "unmutated" = "grey","mutated" = "navy"),
                  P_value = c("slategray1","slategray4", "gray36","gray28"),
                  Importance = c("skyBlue","DeepskyBlue2", "DeepskyBlue3","DeepskyBlue4"))
rownames(annotation_row) = rownames(Data_heatmap1)
rownames(annotation_col) = colnames(Data_heatmap1)
color1 = colorRampPalette(c('black',"blue", "orangered","yellow",'white'))(50)
png(file = paste('./output/RadiogenomicsMap.png.',sep=''), width = 1150, height = 600)
setHook("grid.newpage", function() pushViewport(viewport(x=1,y=1,width=1, height=0.95, name="vp", just=c("right","top"))), action="prepend")
pheatmap(Data_heatmap1, cluster_cols = FALSE, cluster_rows = FALSE, color = color1,
         annotation_row = annotation_row, annotation_col = annotation_col,
         # labels_col = label_col,
         annotation_colors = ann_colors, annotation_names_row = FALSE, fontsize =12,
         scale="row", kmeans_k = NA, border_color = NA, main = "Radiogenomics Map", fontsize_row = 12,
         gaps_col = NULL, gaps_row = 8, show_colnames = FALSE, show_rownames = TRUE )
grid.text("patients", y=-0.01,x=0.33, gp=gpar(fontsize=14))
dev.off()


